﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fourier_Plotter
{
    public class pair
    {
        public int A { get; set; }
        public double B { get; set; }
        public pair(int x, double y)
        {
            A = x;
            B = y;
        }
        public int firstVal()
        {
            return A;
        }
        public double secondVal()
        {
            return B;
        }
    }

}
