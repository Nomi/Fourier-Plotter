﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Fourier_Plotter
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            List<pair> Pairs = new List<pair>();
            Pairs.Add(new pair(100, 1));
            Pairs.Add(new pair(5, 1.54));
            Pairs.Add(new pair(100, 0.1));
            Pairs.Add(new pair(10, 1));
            this.DataContext = Pairs;
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();  // from : https://stackoverflow.com/questions/2820357/how-do-i-exit-a-wpf-application-programmatically
        }

        private void start_Click(object sender, RoutedEventArgs e)
        {

        }

        private void pause_Click(object sender, RoutedEventArgs e)
        {

        }

        private void reset_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
